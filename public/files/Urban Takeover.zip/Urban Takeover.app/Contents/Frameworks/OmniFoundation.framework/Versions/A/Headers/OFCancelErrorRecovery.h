// Copyright 2007 The Omni Group.  All rights reserved.
//
// This software may only be used and reproduced according to the
// terms in the file OmniSourceLicense.html, which should be
// distributed with this project and can also be found at
// <http://www.omnigroup.com/developer/sourcecode/sourcelicense/>.
//
// $Header: svn+ssh://source.omnigroup.com/Source/svn/Omni/trunk/OmniGroup/Frameworks/OmniFoundation/OFErrorRecovery.h 89918 2007-08-10 20:59:55Z bungi $

#import "OFErrorRecovery.h"

@interface OFCancelErrorRecovery : OFErrorRecovery
@end
