(function (document) {
  <body>;
});
